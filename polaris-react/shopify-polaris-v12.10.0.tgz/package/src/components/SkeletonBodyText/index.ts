export * from './SkeletonBodyText';
